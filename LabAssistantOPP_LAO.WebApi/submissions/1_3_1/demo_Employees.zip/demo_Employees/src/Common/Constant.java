/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Common;

/**
 *
 * @author QH
 */
public class Constant {
    public final static String REGCOURSEID ="[\\w]+";
    public final static String REGCOURSENAME ="(?=.*[A-Za-z])[\\w\\s\\.#]+";
    public final static String REGCREDIT ="[1-4]{1}";
    
}
